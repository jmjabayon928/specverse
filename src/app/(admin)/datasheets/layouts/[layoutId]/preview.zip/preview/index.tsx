/**
 * SpecVerse Preview (refactor split) — Performance-safe
 * Strict TypeScript, no `any`. Pure functions + small components.
 * This file is part of: /datasheets/layouts/[layoutId]/preview
 */

// index.tsx — convenience re-export
export { default } from "./PreviewClient";
